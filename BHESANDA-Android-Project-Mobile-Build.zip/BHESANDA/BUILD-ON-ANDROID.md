# Build BHESANDA APK using only an Android phone

This project includes a GitHub Actions workflow so the APK can be compiled in the cloud. You do not need Android Studio or a PC.

## Steps
1. In your phone browser, sign in to GitHub and create a **new public or private repository** named `BHESANDA`.
2. Extract `BHESANDA-Android-Project.zip` on your phone.
3. Open the new GitHub repository in Chrome. Use **Add file → Upload files** and upload the *contents* of the `BHESANDA` folder (including the hidden `.github` folder if your file picker shows hidden files). Commit the files to the `main` branch.
4. Open the repository's **Actions** tab. If GitHub asks, enable Actions for the repository.
5. Select **Build BHESANDA APK** and tap **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish successfully. Open that workflow run, scroll to **Artifacts**, and download `BHESANDA-debug-apk`.
7. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. If Android asks, allow your browser/file manager to install unknown apps.

## Notes
- GitHub account and internet access are required for this cloud-build route.
- Keep the repository private if you do not want the source code public.
- This produces a debug APK for testing, not a Play Store release-signed APK.
