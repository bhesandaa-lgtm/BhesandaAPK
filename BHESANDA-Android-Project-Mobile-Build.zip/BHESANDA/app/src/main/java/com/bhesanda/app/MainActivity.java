package com.bhesanda.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    static final int BG=Color.rgb(8,20,38), CARD=Color.rgb(29,44,65), TEAL=Color.rgb(20,183,164), MUTED=Color.rgb(153,174,196), WHITE=Color.WHITE;
    android.content.SharedPreferences prefs;
    LinearLayout root, body;
    ArrayList<String> saved = new ArrayList<>();
    ArrayList<String> history = new ArrayList<>();
    EditText input, listInput, quantityInput;
    String lastResult="";
    String currentTool="";
    static final int PICK=10, SAVE=11;
    String exportText="";

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(3,32,37));getWindow().setNavigationBarColor(Color.rgb(3,9,18)); prefs=getSharedPreferences("bhesanda",MODE_PRIVATE); load(); home();}
    void load(){ saved.clear(); history.clear(); String s=prefs.getString("urls",""); if(!s.isEmpty()) saved.addAll(Arrays.asList(s.split("\\n"))); String h=prefs.getString("history",""); if(!h.isEmpty()) history.addAll(Arrays.asList(h.split("\\n"))); }
    void persist(){prefs.edit().putString("urls",join(saved)).putString("history",join(history)).apply();}
    String join(List<String> a){StringBuilder b=new StringBuilder();for(String s:a){if(b.length()>0)b.append('\n');b.append(s);}return b.toString();}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void base(String title){root=column();root.setBackgroundColor(BG); ScrollView sc=new ScrollView(this);sc.setFillViewport(true);body=column();body.setPadding(22,22,22,24);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,-1));setContentView(root); TextView head=text(title,25,WHITE,true); body.addView(head);}
    void home(){base("Welcome back,"); TextView brand=text("BHESANDA",34,WHITE,true); brand.setPadding(0,0,0,18);body.addView(brand); EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Search tools...");search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setPadding(18,12,18,12);search.setBackground(shape(CARD,28));body.addView(search,new LinearLayout.LayoutParams(-1,58)); TextView section=text("Utility Tools",22,TEAL,true);section.setPadding(0,30,0,14);body.addView(section);
        String[] names={"Dispenser","Extractor","Cleaner","Duplicate Finder","URL Validator","History","Export Manager","About"};String[] icons={"▤","▣","⌁","▧","✓","◷","⇧","ⓘ"};
        for(int i=0;i<names.length;i+=2){LinearLayout r=row();for(int j=i;j<Math.min(i+2,names.length);j++){final String n=names[j];LinearLayout card=column();card.setGravity(Gravity.CENTER);card.setPadding(8,20,8,20);card.setBackground(shape(CARD,34));TextView ic=text(icons[j],34, j%2==0?0xff48c8ff:0xff45d9ad,true);ic.setGravity(Gravity.CENTER);card.addView(ic);TextView label=text(n,17,WHITE,true);label.setGravity(Gravity.CENTER);label.setPadding(0,12,0,0);card.addView(label);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,150,1);p.setMargins(0,0,10,10);r.addView(card,p);card.setOnClickListener(v->openTool(n));} body.addView(r);}
        TextView foot=text("BHESANDA\nFIREBASE UTILITY TOOLKIT",16,TEAL,true);foot.setGravity(Gravity.CENTER);foot.setPadding(0,34,0,20);body.addView(foot);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){for(int k=0;k<body.getChildCount();k++){View v=body.getChildAt(k);if(v instanceof LinearLayout && ((LinearLayout)v).getChildCount()==2){LinearLayout rr=(LinearLayout)v;for(int q=0;q<rr.getChildCount();q++){View cv=rr.getChildAt(q);if(cv instanceof LinearLayout){String label=((TextView)((LinearLayout)cv).getChildAt(1)).getText().toString();cv.setVisibility(label.toLowerCase().contains(s.toString().toLowerCase())?View.VISIBLE:View.GONE);}}}}}public void afterTextChanged(Editable e){}});
    }
    void openTool(String name){currentTool=name; if(name.equals("History")){showHistory();return;} if(name.equals("About")){about();return;} if(name.equals("Export Manager")){exportManager();return;} base(name); TextView desc=text(toolDescription(name),14,MUTED,false);desc.setPadding(0,10,0,18);body.addView(desc);
        if(name.equals("Dispenser")){ listInput=addInput("Paste or import your authorized Firebase URL list..."); addButton("IMPORT TXT / CSV",()->pickFile()); quantityInput=addInput("Number of entries to dispense"); addButton("DISPENSE",()->dispense()); addButton("SAVE INPUT TO COLLECTION",()->saveInput()); }
        else if(name.equals("Extractor")){addInput("Paste URL containing an encoded Base64 parameter such as ?s=...");addButton("IMPORT TXT / CSV",()->pickFile());addButton("EXTRACT",()->extract());}
        else if(name.equals("Cleaner")){addInput("Paste text to clean...");addButton("IMPORT TXT / CSV",()->pickFile());addButton("CLEAN TEXT",()->cleanText());}
        else if(name.equals("Duplicate Finder")){addInput("Paste URLs or text, one entry per line...");addButton("IMPORT TXT / CSV",()->pickFile());addButton("REMOVE DUPLICATES",()->duplicates());}
        else if(name.equals("URL Validator")){addInput("Paste Firebase URLs, one per line...");addButton("IMPORT TXT / CSV",()->pickFile());addButton("VALIDATE URLS",()->validate());}
        TextView back=text("‹  Back to BHESANDA",15,TEAL,true);back.setPadding(0,26,0,0);body.addView(back);back.setOnClickListener(v->home());
    }
    String toolDescription(String n){switch(n){case "Dispenser":return "Dispense a chosen number of entries from your locally saved or imported list.";case "Extractor":return "Decode supported Base64 URL parameters and extract Firebase URL and Device ID.";case "Cleaner":return "Remove surrounding clutter and normalize pasted text into clean lines.";case "Duplicate Finder":return "Find repeated lines and keep one copy of each entry.";default:return "Check Firebase URL formatting without connecting to the database.";}}
    EditText addInput(String hint){EditText e=new EditText(this);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setHint(hint);e.setGravity(Gravity.TOP|Gravity.START);e.setPadding(16,15,16,15);e.setMinLines(3);e.setBackground(shape(CARD,20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,14);body.addView(e,p);input=e;return e;}
    void addButton(String label,Runnable run){TextView b=text(label,14,WHITE,true);b.setGravity(Gravity.CENTER);b.setPadding(14,17,14,17);b.setBackground(shape(0xff126d69,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,10);body.addView(b,p);b.setOnClickListener(v->run.run());}
    void result(String s){lastResult=s;TextView t=text(s,14,WHITE,false);t.setTextIsSelectable(true);t.setPadding(15,15,15,15);t.setBackground(shape(0xff14243a,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,14,0,10);body.addView(t,p);addButton("COPY RESULT",()->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("BHESANDA",s));toast("Copied");});record(currentTool+" • "+new Date()+" • "+s.replace('\n',' '));}
    void record(String s){history.add(0,s.length()>500?s.substring(0,500):s);while(history.size()>100)history.remove(history.size()-1);persist();}
    void dispense(){String[] lines=(listInput==null?"":listInput.getText().toString()).split("\\r?\\n");ArrayList<String> pool=new ArrayList<>();for(String x:lines)if(isFirebase(x.trim()))pool.add(x.trim());if(pool.isEmpty())pool.addAll(saved);if(pool.isEmpty()){toast("Import or paste your URL collection first");return;}int qty=pool.size();try{String q=quantityInput.getText().toString().trim();if(!q.isEmpty())qty=Integer.parseInt(q);}catch(Exception ignored){} qty=Math.max(0,Math.min(qty,pool.size()));String out=join(pool.subList(0,qty));result("Dispensed: "+qty+"\nRemaining in this input: "+(pool.size()-qty)+"\n\n"+out);}
    void saveInput(){for(String x:(listInput==null?"":listInput.getText().toString()).split("\\r?\\n")){x=x.trim();if(isFirebase(x)&&!saved.contains(x))saved.add(x);}persist();toast("Saved "+saved.size()+" unique Firebase URLs locally");}
    boolean isFirebase(String s){return s.matches("(?i)^https?://[^\\s]+")&&(s.contains("firebaseio.com")||s.contains("firebasedatabase.app"));}
    void extract(){String u=input.getText().toString().trim();try{String enc=null;Matcher m=Pattern.compile("[?&]s=([^&]+)").matcher(u);if(m.find())enc=m.group(1);if(enc==null)throw new Exception("No ?s= parameter found");String decoded=decode64(enc);String fb=findFirebase(decoded);String id=findDeviceId(decoded);String out="Firebase: \""+(fb==null?"Not found":fb)+"\"\n\nDevice ID: \""+(id==null?"Not found":id)+"\"";result(out);}catch(Exception e){toast("Could not decode this link: "+e.getMessage());}}
    String decode64(String x){x=Uri.decode(x);x=x.replace('-','+').replace('_','/');while(x.length()%4!=0)x+="=";return new String(Base64.decode(x,Base64.DEFAULT),StandardCharsets.UTF_8);}
    String findFirebase(String s){Matcher m=Pattern.compile("https?://[A-Za-z0-9.-]+\\.(?:firebaseio\\.com|firebasedatabase\\.app)(?:/[^\\s|,\\\"']*)?",Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?m.group():null;}
    String findDeviceId(String s){String[] pats={"(?i)(?:device[_ ]?id|deviceId|device_id)\\s*[:=|]+\\s*([^|,\\s}]+)"};for(String p:pats){Matcher m=Pattern.compile(p).matcher(s);if(m.find())return m.group(1);}return null;}
    void cleanText(){LinkedHashSet<String> out=new LinkedHashSet<>();for(String l:input.getText().toString().split("\\r?\\n")){String x=l.trim().replaceAll("^[\\s•,;]+|[\\s,;]+$","");if(!x.isEmpty())out.add(x);}result(join(new ArrayList<>(out)));}
    void duplicates(){LinkedHashSet<String> set=new LinkedHashSet<>();int before=0;for(String l:input.getText().toString().split("\\r?\\n")){if(!l.trim().isEmpty()){before++;set.add(l.trim());}}result("Input lines: "+before+"\nUnique lines: "+set.size()+"\nDuplicates removed: "+(before-set.size())+"\n\n"+join(new ArrayList<>(set)));}
    void validate(){ArrayList<String> good=new ArrayList<>(),bad=new ArrayList<>();for(String l:input.getText().toString().split("\\r?\\n")){String x=l.trim();if(x.isEmpty())continue;if(isFirebase(x))good.add(x);else bad.add(x);}result("Valid Firebase URLs: "+good.size()+"\nInvalid / unsupported lines: "+bad.size()+"\n\nVALID\n"+join(good)+"\n\nINVALID\n"+join(bad));}
    void showHistory(){base("Activity History");if(history.isEmpty())body.addView(text("No activity yet.",15,MUTED,false));for(String h:history){TextView t=text(h,13,WHITE,false);t.setPadding(12,14,12,14);t.setBackground(shape(CARD,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);body.addView(t,p);}addButton("CLEAR HISTORY",()->{history.clear();persist();showHistory();});addButton("BACK",()->home());}
    void about(){base("About BHESANDA");TextView n=text("BHESANDA",32,TEAL,true);n.setPadding(0,22,0,8);body.addView(n);body.addView(text("FIREBASE UTILITY TOOLKIT\n\nApp Name: BHESANDA\nDeveloper: @bhesanda\nVersion: 1.0.0\nPlatform: Android\nStorage: Local device only\n\nYour imported lists and history remain on this device. The app does not automatically upload them to a cloud service.",16,WHITE,false));addButton("BACK",()->home());}
    void exportManager(){base("Export Manager");body.addView(text("Export your locally saved Firebase URL collection as a text file.",14,MUTED,false));addButton("EXPORT LAST RESULT",()->{exportText=lastResult;if(exportText.isEmpty()){toast("No result to export yet");return;}createFile("bhesanda_result.txt");});addButton("EXPORT SAVED URLS",()->{exportText=join(saved);if(exportText.isEmpty()){toast("No saved URLs to export");return;}createFile("bhesanda_urls.txt");});addButton("EXPORT HISTORY",()->{exportText=join(history);if(exportText.isEmpty()){toast("No history to export");return;}createFile("bhesanda_history.txt");});addButton("BACK",()->home());}
    void pickFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    void createFile(String name){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,SAVE);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==PICK){InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);String s=out.toString("UTF-8");if(currentTool.equals("Dispenser") && listInput!=null)listInput.setText(s);else if(input!=null)input.setText(s);toast("File imported");}else if(req==SAVE){OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(exportText.getBytes(StandardCharsets.UTF_8));out.close();toast("Export complete");}}catch(Exception e){toast("File operation failed");}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){home();}
}
