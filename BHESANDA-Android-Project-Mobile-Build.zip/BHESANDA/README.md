# BHESANDA Android app (V1.0)

Developer: @bhesanda

## Build
1. Install Android Studio (Hedgehog or newer) and Android SDK Platform 35.
2. Open this `BHESANDA` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## V1 features
- Home dashboard with separate cards for Dispenser, Extractor, Cleaner, Duplicate Finder, URL Validator, History, Export Manager and About.
- Local-only saved URL collection and activity history using SharedPreferences.
- TXT/CSV-compatible file import (line-based text processing) and TXT export.
- Extractor decodes a Base64 `s` query parameter and attempts to identify a Firebase Realtime Database URL and Device ID.
- No network permission or automatic cloud upload.

## Notes
- Dispenser works with Firebase URL entries pasted or imported by the user, or entries saved locally.
- URL validation checks Firebase Realtime Database URL formats; it does not connect to or inspect database contents.
- The Base64 payload structure can vary by source. Device ID extraction supports common labeled formats; adjust parsing once you provide representative sample links.
- This environment did not have Android SDK/Gradle installed, so an APK could not be compiled here. Open the project in Android Studio to build the installable APK.

## Build using an Android phone only
See `BUILD-ON-ANDROID.md`. A GitHub Actions workflow is included at `.github/workflows/build-apk.yml` to compile the debug APK in the cloud.
